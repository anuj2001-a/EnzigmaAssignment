const mysql = require('mysql2')

const pool = mysql.createPool({
    host: 'localhost',
    port: 3306,
    user: 'D4_87082_ANUJ',
    password: 'manager',
    database: 'Todo_db'
})

module.exports = pool