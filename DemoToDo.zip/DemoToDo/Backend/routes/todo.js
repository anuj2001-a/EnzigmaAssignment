const express = require('express')
const utils = require('../utils')
const db = require('../db')

const router = express.Router()

router.post('/', (req, res) => {
    const {title, details} = req.body
    const stmt = `INSERT INTO todoitem(title, details, userId) VALUES(?, ?, ?)`

    db.execute(stmt, [title, details, req.user.id], (error, result) => {
        res.send(utils.createResult(error, result))
    })
})

router.get('/my', (req, res) => {
    const stmt = `SELECT id, title, details, createdTimestamp, isPublic FROM todoitem WHERE userid=?`

    db.query(stmt, [req.user.id], (error, items) => {
        res.send(utils.createResult(error, items))
    })
})

router.get('/public', (req, res) => {
    const stmt = `SELECT t.id, t.title, t.details, t.createdTimestamp, u.firstName, u.lastName 
    FROM todoitem t, user u WHERE t.userId = u.id AND ispublic=1`
    db.query(stmt, (error, items) => {
        res.send(utils.createResult(error, items))
    })
})

router.delete('/delete/:itemId', (req, res) => {
    const {itemId} = req.params
    const stmt = `DELETE FROM todoitem WHERE userId=? AND id=?`

    db.execute(stmt, [req.user.id, itemId], (error, result) => {
        res.send(utils.createResult(error, result))
    })
})

router.patch('/makePublic/:itemId', (req, res) => {
    const {itemId} = req.params
    const stmt = `UPDATE todoitem SET isPublic=1 WHERE id=? and userId=?`

    db.execute(stmt, [itemId, req.user.id], (error, result) => {
        res.send(utils.createResult(error, result))
    })
})

router.patch('/makePrivate/:itemId', (req, res) => {
    const {itemId} = req.params
    const stmt = `UPDATE todoitem SET isPublic=0 WHERE id=? and userId=?`

    db.execute(stmt, [itemId, req.user.id], (error, result) => {
        res.send(utils.createResult(error, result))
    })
})

router.get('/search/:text', (req, res) => {
    const {text} = req.params
    const stmt = `SELECT id, title, details, createdTimestamp FROM todoitem 
    WHERE isPublic=1 AND (title LIKE '%${text}%' OR details LIKE '%${text}%')`

    db.query(stmt, (error, result) => {
        res.send(utils.createResult(error, result))
    })
}) 

module.exports = router