const express = require('express')
const db = require('../db')
const utils = require('../utils')
const crypto = require('crypto-js')
const jwt = require('jsonwebtoken')
const config = require('../config')
const mailer = require('../mailer')

const router = express.Router()

router.post('/login', (req, res) => {
    const {email, password} = req.body
    const stmt= `SELECT id, firstname, lastname, phone, isActive FROM user WHERE email=? AND password=?`
    const encryptedPw = String(crypto.MD5(password))

    db.query(stmt, [email, encryptedPw], (error, users) => {
        if(error) {
            res.send(utils.createError(error))
        }
        else {
            if(users.length == 0) {
                res.send(utils.createError('User does not exist...'))
            }
            else {
                const {id, firstName, lastName, phone, isActive} = users[0]

                if(isActive) {
                    const payload = {id, firstName, lastName, phone}
                    const token = jwt.sign(payload, config.secret)

                    res.send(utils.createSuccess({token, firstName, lastName, phone}))
                }
                else {
                    res.send(utils.createError
                        (`You can not login as your account is not active. Please contact administrator.`))
                }
            }
        }
    })
})

router.post('/register', (req, res) => {
    const {firstName, lastName, email, phone, password} = req.body
    const encryptedPw = String(crypto.MD5(password))
    const otp = Math.floor(Math.random()*1000000)
    const stmt = `INSERT INTO user(firstname, lastname, email, phone, password, verificationOTP) 
    VALUES (?, ?, ?, ?, ?, ?)`

    db.execute(stmt, [firstName, lastName, email, phone, encryptedPw, otp], (error, result) => {
        if(!error) {
            // mailer.sendEmail(
            //     email,
            //     `Welcome to TODO application.`,
            //     `
            //     <h1>Welcome to TodoApp</h1>
            //     <div>Hi ${firstName}, </div>
            //     <br/>
            //     <div>Thank your registering with us. This app ......</div>
            //     <br/>
            //     <div>Your OTP is: <h3>${otp}</h3></div>
            //     <div>Verify your account here: ...</div>
            //     <br/>
            //     <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
            //     <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
            //     <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>

            //     <br/>
            //     <div>Thank you,</div>
            //     <div>TodoApp.</div>
            //     `, () => {
            //         res.send(utils.createResult(error, result))
            //     }
            // )
            res.send(utils.createSuccess(result))
        }
        else {
            res.send(utils.createError(error))
        }
    })
})

router.patch('/verify', (req, res) => {
    const {email, otp} = req.body
    const stmt = `SELECT id FROM user WHERE email=? AND verificationOTP=?`

    db.query(stmt, [email, otp], (error, users) => {
        if(error) {
            res.send(utils.createError(error))
        }
        else {
            if(users.length == 0) {
                res.send(utils.createError('Invalid OTP or email'))
            }
            else {
                const {id} = users[0]
                const stmt2 = `UPDATE user SET isActive=1 WHERE id=?`

                db.execute(stmt2, [id], (error, result) => {
                    res.send(utils.createResult(error, result))
                }) 
            }
        }
    })
})

router.get('/profile', (req, res) => {
    const stmt = `SELECT firstName, lastName, email, phone FROM user WHERE id=?`

    db.query(stmt, [req.user.id], (error, users) => {
        if(error) {
            res.send(utils.createError(error))
        }
        else {
            if(users.length === 0) {
                res.send(utils.createError('User does not exist'))
            }
            else {
                res.send(utils.createSuccess(users[0]))
            }
        }
    })
})

router.put('/profile', (req, res) => {
    const {firstName, lastName, phone} = req.body
    const stmt = `UPDATE user SET firstName=?, lastName=?, phone=? WHERE id=?`

    db.execute(stmt, [firstName, lastName, phone, req.user.id], (error, result) => {
        res.send(utils.createResult(error, result))
    })
})

router.patch('/password', (req, res) => {
    const {password} = req.body
    const encryptedPw = String(crypto.MD5(password))
    const stmt = `UPDATE user SET password=? WHERE id=?`

    db.execute(stmt, [encryptedPw, req.user.id], (error, result) => {
        res.send(utils.createResult(error, result))
    })
})

module.exports = router