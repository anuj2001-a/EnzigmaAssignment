const express = require('express')
const jwt = require('jsonwebtoken')
const config = require('./config')
const utils = require('./utils')
const cors = require('cors')

const app = express()

app.use(cors())

app.use(express.json())

app.use((req, res, next) => {
    if(req.url=='/user/login' || req.url=='/user/register' || req.url=='/user/verify') {
        next()
    }
    else {
        const token = req.headers['token']

        if(!token) {
            res.send(utils.createError('missing token'))
        }
        else {
            try {
                const payload = jwt.verify(token, config.secret)
                req.user = payload
                next()
            }
            catch(e) {
                res.send(utils.createError("invalid token"))
            }
        }
    }
})

const userRouter = require('./routes/user')
const todoRouter = require('./routes/todo')

app.use('/user', userRouter)
app.use('/todo', todoRouter)

app.listen(4000, '0.0.0.0', () => {
    console.log(`Server is running on port 4000`)
})