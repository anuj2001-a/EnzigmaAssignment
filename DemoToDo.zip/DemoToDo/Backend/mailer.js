/*const nodemailer = require('nodemailer')
const config = require('./config')

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: config.email.user,
        pass: config.email.password
    }
})

async function sendEmail(email, subject, body, callback) {
    await transporter.sendMail({
        to: email,
        subject,
        html: body
    })

    callback()
}

module.exports = {
    sendEmail
}
    */